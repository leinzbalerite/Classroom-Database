class Creds:
    conString = 'cis3368spring.c70oq600w483.us-east-1.rds.amazonaws.com'
    userName = 'admin'
    password = 'leilawashere'
    dbName = 'cis3368springdb'